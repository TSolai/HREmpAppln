﻿Imports System.Data.SqlClient

Public Class DAL

    Dim m_Connection As SqlConnection

    Private Sub ConOpen()
        m_Connection = New SqlConnection(
          ConfigurationManager.AppSettings.Item("conStrHREmp"))
        m_Connection.Open()
    End Sub

    Protected Sub ConClose()
        m_Connection.Close()
    End Sub

    Public Function GetAllDepartment() As SqlDataReader
        ConOpen()
        Dim mCom As New SqlCommand("[usp_GetAllDepartment]", m_Connection)
        mCom.CommandType = CommandType.StoredProcedure
        Dim mdr As SqlDataReader = mCom.ExecuteReader()
        Return mdr
    End Function

    Public Function GetAllEmployeeDet() As SqlDataReader
        ConOpen()
        Dim mCom As New SqlCommand("[usp_GetAllEmployeeDet]", m_Connection)
        mCom.CommandType = CommandType.StoredProcedure
        Dim mdr As SqlDataReader = mCom.ExecuteReader()

        Return mdr
    End Function


    Public Function EmployeeDelete(EmployeeNumber As String) As Integer
        ConOpen()
        Dim mCom As New SqlCommand("[usp_EmployeeDelete]", m_Connection)
        mCom.CommandType = CommandType.StoredProcedure


        Dim mParam As SqlParameter = mCom.Parameters.Add("@EmployeeNumber", SqlDbType.VarChar, 10)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = EmployeeNumber
        End With



        mCom.ExecuteNonQuery()

        EmployeeDelete = 1

    End Function


    Public Function EmployeeUpdate(EmployeeNumber As String, FirstName As String, LastName As String, DateofBirth As String, DepartmentId As Integer, Address As String, City As String) As Integer
        ConOpen()
        Dim mCom As New SqlCommand("[usp_EmployeeUpdate]", m_Connection)
        mCom.CommandType = CommandType.StoredProcedure


        Dim mParam As SqlParameter = mCom.Parameters.Add("@EmployeeNumber", SqlDbType.VarChar, 10)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = EmployeeNumber
        End With


        mParam = mCom.Parameters.Add("@FirstName", SqlDbType.VarChar, 50)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = FirstName
        End With


        mParam = mCom.Parameters.Add("@LastName", SqlDbType.VarChar, 50)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = LastName
        End With


        mParam = mCom.Parameters.Add("@DateofBirth", SqlDbType.Date)
        With mParam
            .Direction = ParameterDirection.Input
            If IsDate(DateofBirth) Then
                .Value = CDate(DateofBirth).ToString("yyyy-MM-dd")
            End If
        End With

        mParam = mCom.Parameters.Add("@DepartmentId", SqlDbType.Int)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = DepartmentId
        End With

        mParam = mCom.Parameters.Add("@City", SqlDbType.VarChar, 50)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = City
        End With

        mParam = mCom.Parameters.Add("@Address", SqlDbType.VarChar, 100)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = Address
        End With

        mParam = mCom.Parameters.Add("@isDeleted", SqlDbType.Bit)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = 0
        End With


        EmployeeUpdate = mParam.Value
    End Function


    Public Function EmployeeInsert(EmployeeNumber As String, FirstName As String, LastName As String, DateofBirth As String, DepartmentId As Integer, Address As String, City As String) As Integer
        ConOpen()
        Dim mCom As New SqlCommand("[usp_EmployeeInsert]", m_Connection)
        mCom.CommandType = CommandType.StoredProcedure


        Dim mParam As SqlParameter = mCom.Parameters.Add("@EmployeeNumber", SqlDbType.VarChar, 10)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = EmployeeNumber
        End With


        mParam = mCom.Parameters.Add("@FirstName", SqlDbType.VarChar, 50)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = FirstName
        End With


        mParam = mCom.Parameters.Add("@LastName", SqlDbType.VarChar, 50)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = LastName
        End With


        mParam = mCom.Parameters.Add("@DateofBirth", SqlDbType.Date)
        With mParam
            .Direction = ParameterDirection.Input
            If IsDate(DateofBirth) Then
                .Value = CDate(DateofBirth).ToString("yyyy-MM-dd")
            End If
        End With

        mParam = mCom.Parameters.Add("@DepartmentId", SqlDbType.Int)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = DepartmentId
        End With

        mParam = mCom.Parameters.Add("@City", SqlDbType.VarChar, 50)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = City
        End With

        mParam = mCom.Parameters.Add("@Address", SqlDbType.VarChar, 100)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = Address
        End With

        mParam = mCom.Parameters.Add("@isDeleted", SqlDbType.Bit)
        With mParam
            .Direction = ParameterDirection.Input
            .Value = 0
        End With


        mParam = mCom.Parameters.Add("@EmployeeNumberOut", SqlDbType.Int)
        mParam.Direction = ParameterDirection.Output

        mCom.ExecuteNonQuery()

        EmployeeInsert = mParam.Value
    End Function

End Class
