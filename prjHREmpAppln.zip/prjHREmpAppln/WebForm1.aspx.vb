﻿Public Class WebForm1
    Inherits System.Web.UI.Page
    Dim obj As New DAL
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not Page.IsPostBack Then
            loadDepartment()
            LoadEmpDet()

        End If
    End Sub

    Sub LoadEmpDet()
        empDet.DataSource = obj.GetAllEmployeeDet()
        empDet.DataBind()
    End Sub

    Sub loadDepartment()
        Department.DataSource = obj.GetAllDepartment()
        Department.DataTextField = "DepartmentName"
        Department.DataValueField = "DepartmentId"

        Department.DataBind()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        obj.EmployeeInsert(EmployeeNumber.Text, FirstName.Text, LastName.Text, DateofBirth.Text, Department.SelectedValue, FirstName.Text & LastName.Text & "Addr", FirstName.Text & LastName.Text & "City")
    End Sub
End Class